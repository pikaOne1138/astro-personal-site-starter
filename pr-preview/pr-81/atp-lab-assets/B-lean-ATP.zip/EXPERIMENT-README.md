# B 組：精簡 ATP（實驗版）
測試 1 接收自然語言原始需求，由 AI 自行訪談並整理需求規格；測試 2 才與 A 組共用 Site Brief。這包只縮減文件及 Skills 的讀取範圍，保留匯出器及其依賴原始碼，並不是全新的 Layout Generator。
1. 先讀 AGENTS.md 與 .ai/astro-site-assembly/SKILL.md。測試 1 先訪談、在 AI 工作區自行完成符合既有 schema 的 Site Brief，不能要求學員先去規劃器。測試 2 直接使用給定 Site Brief。
2. 根據所選 Layout 只讀相關檔案；按需讀設計、內容、部署 Skills。
3. 使用 node scripts/export-starter.mjs brief.json output-dir 產生獨立 Astro，之後安裝依賴並建置；執行環境需具備 Node。
4. 不因 ZIP 小就推論網站品質較高；不得自行發布 Production。
