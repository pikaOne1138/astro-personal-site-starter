import {mkdtempSync,mkdirSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
const root=mkdtempSync(join(tmpdir(),'draft-negative-gate-'));
const put=(p,text)=>{const full=join(root,p);mkdirSync(join(full,'..'),{recursive:true});writeFileSync(full,text)};
const html=(body='')=>'<html><head><title>Test page</title><meta name="description" content="fixture"><link rel="canonical" href="https://example.com/"></head><body>'+body+'</body></html>';
const draft='qa-secret-draft',title='Never Publish This Example Draft';
const article='---\ntitle: '+title+'\ndescription: For private draft QA only\npublishedAt: 2026-10-09\ndraft: true\n---\nDraft text';
try{
 put('site.config.json',JSON.stringify({navigation:[]}));
 put('src/content/articles/'+draft+'.md',article);
 put('dist/index.html',html('Public home'));
 put('dist/404.html',html('Not Found'));
 put('dist/rss.xml','<rss version="2.0"></rss>');
 put('dist/sitemap.xml','<urlset></urlset>');
 put('dist/robots.txt','User-agent: *\nSitemap: https://example.com/sitemap.xml\n');
 put('dist/pagefind/pagefind.js','/* QA Pagefind fixture */');
 put('dist/search/exact-zh.json',JSON.stringify({version:1,docs:[]}));
 const run=()=>spawnSync(process.execPath,['scripts/verify-v2-8-output.mjs','--student-site',root],{encoding:'utf8'});
 const expect=(name,ok)=>{const p=run();if((p.status===0)!==ok)throw Error(name+': expected '+(ok?'PASS':'FAIL')+'; got '+p.status+'\n'+p.stdout+'\n'+p.stderr);console.log(name+': '+(ok?'PASS':'correctly rejected'))};
 expect('clean draft',true);
 put('dist/index.html',html('這裡尚未填入個人的正式內容'));
 const notice=run();if(notice.status!==0||!notice.stderr.includes('NOTICE:'))throw Error('Placeholder content must be NOTICE, not blocking FAIL');
 put('dist/index.html',html('Public home'));
 put('dist/index.html',html('<a href="/articles/'+draft+'/">'+title+'</a>'));
 expect('draft in homepage',false);
 put('dist/index.html',html());
 put('dist/rss.xml','<rss version="2.0"><item><link>https://example.com/articles/'+draft+'/</link></item></rss>');
 expect('draft in RSS',false);
 put('dist/rss.xml','<rss version="2.0"></rss>');
 put('dist/sitemap.xml','<urlset><url><loc>https://example.com/articles/'+draft+'/</loc></url></urlset>');
 expect('draft in sitemap',false);
 put('dist/sitemap.xml','<urlset></urlset>');
 put('dist/articles/'+draft+'/index.html',html(title));
 expect('draft HTML route',false);
 // The new public-source isolation rule: drafts live outside the articles Collection.
 put('dist/articles/'+draft+'/index.html','');
 const {unlinkSync}=await import('node:fs');
 unlinkSync(join(root,'dist/articles/'+draft+'/index.html'));
 put('src/content/drafts/folder-only.md',article.replace('qa-secret-draft','folder-only'));
 expect('isolated draft clean output',true);
 put('dist/index.html',html('<a href="/articles/folder-only/">Never Publish This Example Draft</a>'));
 expect('isolated draft leaked in homepage',false);
 put('dist/index.html',html());
 // A draft title under eight Chinese characters must still be considered sensitive.
 put('src/content/drafts/short-secret.md',article.replace('Never Publish This Example Draft','小秘密草稿'));
 put('dist/index.html',html('小秘密草稿'));
 expect('short Chinese draft title leaked',false);
 put('dist/index.html',html());
 // Search JSON is a public endpoint and must be audited like public HTML.
 put('dist/search/exact-zh.json',JSON.stringify({version:1,docs:[{title:'小秘密草稿',url:'/articles/short-secret/'}]}));
 expect('draft in public JSON search',false);
 put('dist/search/exact-zh.json',JSON.stringify({version:1,docs:[]}));
 expect('clean public JSON',true);
 // F11: the validator must reject missing Pagefind or Chinese companion indexes.
 unlinkSync(join(root,'dist/pagefind/pagefind.js'));
 expect('F11 missing Pagefind index',false);
 put('dist/pagefind/pagefind.js','/* QA Pagefind fixture */');
 unlinkSync(join(root,'dist/search/exact-zh.json'));
 expect('F11 missing Chinese index',false);
 put('dist/search/exact-zh.json','{invalid json');
 expect('F11 malformed Chinese index',false);
 put('dist/search/exact-zh.json',JSON.stringify({version:1,docs:[]}));
 expect('F11 restored search baseline',true);
}finally{rmSync(root,{force:true,recursive:true})}
