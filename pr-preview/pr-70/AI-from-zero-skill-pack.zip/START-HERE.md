# 直接與 AI 討論建站｜AI Skill 資料包

這份 ZIP 只有 AI 操作 Skill 和必要的共用守則，不是可直接執行的 Astro 網站；建站 AI 需有檔案操作和建置能力。
先讀 .ai/astro-site-entry/SKILL.md，然後讀 .ai/astro-site-from-zero/SKILL.md，其他 Skills 依實際工作按需讀取。
不必先產生 Site Brief JSON，也不必登入老師的 Repository。使用者明確同意前不可 Merge 或正式發布。
