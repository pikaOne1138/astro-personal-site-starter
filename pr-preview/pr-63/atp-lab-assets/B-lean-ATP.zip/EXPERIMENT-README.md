# B 組：精簡 ATP（實驗版）
與 A 組共用 Site Brief。這包只縮減文件及 Skills 的讀取範圍，保留匯出器及其依賴原始碼，並不是全新的 Layout Generator。
1. 先讀 START-HERE.md、AGENTS.md 與 .ai/astro-site-assembly/SKILL.md。
2. 根據所選 Layout 只讀相關檔案；按需讀設計、內容、部署 Skills。
3. 使用 node scripts/export-starter.mjs brief.json output-dir 產生獨立 Astro，之後安裝依賴並建置；執行環境需具備 Node。
4. 不因 ZIP 小就推論網站品質較高；不得自行發布 Production。
