# C 組對照包
空白、可建置的 Astro 起點加一份自主建站 Skill。這不是完成網站，須由 AI 用相同 Brief 從零實作。
AI 應讀 SKILL.md、Site Brief JSON；npm install && npm run build。
