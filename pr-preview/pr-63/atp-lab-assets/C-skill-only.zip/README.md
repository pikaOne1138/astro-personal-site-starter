# C 組對照包
空白、可建置的 Astro 起點加一份自主建站 Skill。這不是完成網站，須由 AI 用相同 Brief 從零實作。
測試 1 請 AI 讀 SKILL.md 與原始需求，自行訪談，不需預先提供 Site Brief；測試 2 才給 Site Brief JSON。執行 npm install && npm run build。
