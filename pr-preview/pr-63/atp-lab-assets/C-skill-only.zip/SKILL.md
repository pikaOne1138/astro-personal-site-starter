---
name: atp-skill-only-site-build
description: Build a standalone Astro personal site from a supplied Site Brief without ATP's layout library or blocks.
---
# C 組：Skill 自主建站（對照組）
輸入是與 A、B 完全相同的 Site Brief JSON。網站類型僅為知識／部落格或助人者／個人專業服務。先驗證所需資訊，再依目的規劃資訊架構、設計、Astro 靜態路由、文章或服務內頁與響應式互動。不得借用 A/B 的 Layout/Blocks 原始碼。可使用 Astro 的標準 API 和原生 CSS/JS；依任務自行撰寫可維護的元件。
不得虛構資格、服務價目、見證、預約成功、電子報或表單後端。缺少的內容標示待設定。保留網站自身連結，不將文章導回參考網站。
請實際執行 npm run build，檢查首頁與內頁在 1440/1280/768/390、鍵盤與動態減量。Build 不等於視覺 QA；無瀏覽器工具須註明未驗證。先建立 Branch/PR 並取得真實 Preview，使用者明確同意前不得 Merge 或正式發布。
