import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync,copyFileSync,cpSync} from 'node:fs';
import {resolve,join,dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
import {finalizeStudentSite} from './student-project-context.mjs';
import {getLayoutDefinition} from '../src/data/layout-assembly/definitions.mjs';
import {checkStartRecordFile} from './check-start-record.mjs';
import {themeCss} from './theme-css.mjs';
import {writeDesignBaseline} from './design-scan.mjs';
const [input,dest]=process.argv.slice(2);
if(!input||!dest)throw Error('Usage: node scripts/export-starter.mjs plan.json output-dir');
// G-00: first-time assembly needs a confirmation record. Route B may omit the flag (the downloaded Site Brief is its basis); routes A and C pass the record file. Maintenance of an existing site never runs the exporter.
const startFlag=process.argv.indexOf('--require-start-record');
if(startFlag>=0){
 const gate=checkStartRecordFile(process.argv[startFlag+1]||'PROJECT.md');
 if(!gate.ok){console.error('G-00 開工紀錄 FAIL：'+gate.learnerMessage);for(const e of gate.errors)console.error('  '+e);process.exit(1);}
 console.log('G-00 開工紀錄 PASS：路線 '+gate.route+'，'+gate.recordStatus+(gate.confirmedAt?'，'+gate.confirmedAt:''));
}
const plan=JSON.parse(readFileSync(resolve(input),'utf8'));
const selected=getLayoutDefinition(plan.layoutSlug,plan.kind);
if(selected?.adapter?.engine){
 if(process.argv.includes('--require-ready'))throw Error('Layout has no Ready approval: '+plan.layoutSlug);
 const result=spawnSync(process.execPath,[new URL('./export-art-direction-starter.mjs',import.meta.url).pathname,input,dest,'--allow-in-progress'],{stdio:'inherit'});
 process.exit(result.status??1);
}
const layouts=JSON.parse(readFileSync(new URL('../src/data/layout-directions.json',import.meta.url),'utf8'));
const patterns=JSON.parse(readFileSync(new URL('../src/data/section-patterns.registry.json',import.meta.url),'utf8'));
const allowed={knowledge:['articles','topics','start-here','about','resources'],helper:['services','first-visit','about','faq','articles','booking']};
const nav=(plan.navigation||[]).filter(x=>x.enabled);
const navigationInput=plan.navigation||[];
if(Array.isArray(navigationInput)){
 const byId=new Map(navigationInput.map(item=>[item.id,item]));
 for(const item of navigationInput.filter(item=>item.enabled!==false&&item.parentId)){
  const parent=byId.get(item.parentId);
  if(parent?.parentId)throw Error('Navigation supports at most two levels: "'+item.label+'" has a second-level parent "'+parent.label+'". Move it under a top-level page.');
  if(!parent||parent.enabled===false)throw Error('Navigation parent missing or disabled for "'+item.label+'": '+item.parentId);
 }
}
if(plan.version!==1||!allowed[plan.kind]||!layouts.some(l=>l.kind===plan.kind&&l.slug===plan.layoutSlug)||!['paper','morning','studio','botanical','ocean','sand','slate','lavender'].includes(plan.visualTheme)||!/^#[0-9a-fA-F]{6}$/.test(plan.brand?.primaryColor||'')||!plan.brand?.name?.trim()||nav.length<2||nav.length>20||nav.filter(x=>!x.parentId).length>12||nav.some(x=>(!allowed[plan.kind].includes(x.id)&&!/^page-[a-z0-9-]{1,32}$/.test(x.id))||!x.label?.trim())||nav.some(x=>x.parentId&&(!nav.some(parent=>parent.id===x.parentId&&!parent.parentId)||x.parentId===x.id))||nav.some(x=>x.parentId&&nav.filter(y=>y.parentId===x.parentId).length>10)||new Set(nav.map(x=>x.id)).size!==nav.length||!nav.some(x=>x.id===plan.primaryCta?.pageId))throw Error('Invalid StarterPlan');
if(nav.some(x=>x.id==='articles'&&x.path&&x.path!=='articles/'))throw Error('Article archive path is fixed at articles/');
const paths=nav.map(x=>x.path??x.id+'/');
if(paths.some(p=>!/^([a-z0-9-]+\/)+$/.test(p)||(p.startsWith('articles/')&&p!=='articles/')||p.includes('//'))||new Set(paths).size!==paths.length)throw Error('Invalid custom navigation route');
const selections=plan.sectionPatterns||[];
if(!Array.isArray(selections))throw Error('Invalid sectionPatterns');
if(selections.filter(x=>x.patternId?.startsWith('footer-')).length>1)throw Error('Only one footer pattern is allowed');
if(selections.some(x=>{
 const definition=patterns.find(p=>p.id===x.patternId);
 return !definition||!definition.kind.includes(plan.kind)||!x.insertAfter?.trim()||x.insertAfter.length>180||
 (x.patternId.startsWith('footer-')?x.targetPage!=='site-wide':!(x.targetPage==='/'||nav.some(n=>n.id===x.targetPage)));
})||new Set(selections.map(x=>x.patternId+'@'+x.targetPage)).size!==selections.length)throw Error('Invalid pattern selection or target route');
if(plan.brand?.palette){const colors=plan.brand.palette;if(['primary','secondary','accent','background','text'].some(key=>!/^#[0-9a-fA-F]{6}$/.test(colors[key]||''))||colors.primary.toUpperCase()!==plan.brand.primaryColor.toUpperCase())throw Error('Invalid five-color brand palette');}
const layoutDefinition=getLayoutDefinition(plan.layoutSlug,plan.kind);
const hasAssemblyAdapter=Boolean(layoutDefinition?.adapter);
if(process.argv.includes('--require-assembled')&&!hasAssemblyAdapter)
  throw Error('Selected layout is Prototype only; no independent assembly adapter yet: '+plan.layoutSlug+'. Export a Site Brief or choose a supported layout.');
if(!hasAssemblyAdapter)console.warn('PROTOTYPE / SCAFFOLD ONLY: '+plan.layoutSlug+' requires actual layout composition work before publishing.');
if(plan.brand?.imageFit&&!['cover','contain'].includes(plan.brand.imageFit))throw Error('Invalid image fit');
if(plan.brand?.imagePosition&&!['center','top','bottom','left','right'].includes(plan.brand.imagePosition))throw Error('Invalid image position');
const typography=plan.brand?.typography??'editorial-serif';
const imageStyle=plan.brand?.imageStyle??'natural';
if(!['editorial-serif','clear-sans','balanced'].includes(typography)||!['natural','documentary','minimal'].includes(imageStyle))throw Error('Invalid typography or image style');
if(plan.brand?.heroImagePath&&!/^\/images\/[a-z0-9/_-]+\.(webp|png|jpe?g|avif)$/i.test(plan.brand.heroImagePath))throw Error('Hero image must be a local /images/ asset');
if(plan.brand?.heroImageAlt&&(!plan.brand.heroImagePath||plan.brand.heroImageAlt.length>180))throw Error('Invalid hero image alt text');
// Strict self-contained attachments: users can provide local images in the browser planner.
const attachments=Array.isArray(plan.assets)?plan.assets:[];
if(attachments.length>2)throw Error('Maximum two attached images: logo and hero.');
const embedded=new Map();
const mimeExtension={png:'image/png',jpg:'image/jpeg',webp:'image/webp',avif:'image/avif'};
for(const asset of attachments){
 if(!/^\/images\/(brand-logo|hero-image)\.(png|jpg|webp|avif)$/.test(asset.path))throw Error('Invalid attached image path');
 const ext=asset.path.split('.').pop();
 if(asset.mime!==mimeExtension[ext]||typeof asset.base64!=='string'||asset.base64.length>6000000||!/^[A-Za-z0-9+/]+={0,2}$/.test(asset.base64))throw Error('Invalid attached image data');
 if(embedded.has(asset.path))throw Error('Duplicate attached image path');
 const bytes=Buffer.from(asset.base64,'base64');
 if(bytes.byteLength>4500000||bytes.byteLength===0)throw Error('Attached image exceeds 4 MB or empty');
 embedded.set(asset.path,bytes);
}
// Image ownership gate: a Site Brief path is not an uploaded file.
if(plan.brand?.logoPath&&!/^\/images\/[a-z0-9/_-]+\.(webp|png|jpe?g|avif)$/i.test(plan.brand.logoPath))throw Error('Logo must be a local raster image in /images/');
const logoSource=plan.brand?.logoPath?resolve(dirname(resolve(input)),'public',plan.brand.logoPath.slice(1)):null;
if(logoSource&&!existsSync(logoSource)&&!embedded.has(plan.brand.logoPath))throw Error('Missing local logo '+plan.brand.logoPath+'; place it in public/images/ beside your Site Brief.');
const imageSource=plan.brand?.heroImagePath?resolve(dirname(resolve(input)),'public',plan.brand.heroImagePath.slice(1)):null;
if(imageSource&&!existsSync(imageSource)&&!embedded.has(plan.brand.heroImagePath))throw Error('Missing licensed hero image '+plan.brand.heroImagePath+'; place the asset beside your Site Brief under public/images/ before generating.');
const content=plan.content??{};
if(typeof content!=='object'||(content.headline!==undefined&&(typeof content.headline!=='string'||content.headline.length>120))||(content.intro!==undefined&&(typeof content.intro!=='string'||content.intro.length>800)))throw Error('Invalid homepage copy');
 // Optional content metadata is explicit; templates never invent books or verified services.
const reading=plan.layoutSlug==='reading-atlas'?plan.reading:undefined;
if(reading?.records&&(!Array.isArray(reading.records)||reading.records.length>180||reading.records.some(x=>!/^(0[1-9]|1[0-2])$/.test(x.month)||typeof x.title!=='string'||!x.title.trim()||x.title.length>150||typeof x.note!=='string'||x.note.length>1000)))throw Error('Reading records need month (01-12), title and note');
if(reading?.annualBook&&(!reading.annualBook.title?.trim()||!reading.annualBook.note?.trim()))throw Error('Annual book must include an owned title and explanation');
const about=plan.about??{};
if(typeof about!=='object'||Array.isArray(about)||Object.entries(about).some(([key,value])=>!['bio','purpose','approach','background'].includes(key)||typeof value!=='string'||value.length>1200))throw Error('Invalid owned About content');
const serviceFacts=plan.kind==='helper'?plan.serviceFacts:undefined;
if(serviceFacts&&Object.entries(serviceFacts).some(([k,v])=>!['duration','price','cancellation','qualification','contact','scope','exclusions','method','firstVisit'].includes(k)||typeof v!=='string'||v.length>500))throw Error('Invalid verified service facts');
// Optional owned collective content and verified timing, never fabricated roster/events.
const team=plan.layoutSlug==='collective'?(plan.team??[]):[];
if(!Array.isArray(team)||team.length>12||team.some(x=>typeof x.name!=='string'||!x.name.trim()||x.name.length>80||typeof x.role!=='string'||x.role.length>200||typeof x.bio!=='string'||x.bio.length>800))throw Error('Invalid owned team content');
const events=plan.layoutSlug==='collective'?(plan.events??[]):[];
const eventURL=value=>{try{const u=new URL(value);return u.protocol==='https:'&&Boolean(u.hostname)&&!u.username&&!u.password}catch{return false}};
const eventDate=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&!Number.isNaN(new Date(value+'T00:00:00Z').getTime())&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
if(!Array.isArray(events)||events.length>24||events.some(x=>typeof x.title!=='string'||!x.title.trim()||x.title.length>150||typeof x.description!=='string'||x.description.length>800||!eventDate(x.date)||!eventURL(x.url)))throw Error('Events require real title, date and HTTPS destination');
const serviceTiming=plan.layoutSlug==='trust-path'?(plan.serviceTiming??[]):[];
if(!Array.isArray(serviceTiming)||serviceTiming.length>8||serviceTiming.some(x=>typeof x.label!=='string'||!x.label.trim()||x.label.length>80||!Number.isInteger(x.minutes)||x.minutes<1||x.minutes>240))throw Error('Timing needs owned labels and positive minute counts');
const exactDuration=serviceFacts?.duration?.trim().match(/^(\d+)\s*分鐘$/);
if(serviceTiming.length&&exactDuration&&serviceTiming.reduce((sum,x)=>sum+x.minutes,0)!==Number(exactDuration[1]))throw Error('Provided timing total differs from service duration');
// Audio is an explicit optional owned asset, never a borrowed playable demo.
const media=plan.layoutSlug==='radio-letter'?plan.media:undefined;
if(media?.episodeAudioPath&&!/^\/audio\/[a-z0-9/_-]+\.(mp3|ogg|wav|m4a)$/i.test(media.episodeAudioPath))throw Error('Episode audio must be a local /audio/ file');
if(media?.episodeTranscript&&(!Array.isArray(media.episodeTranscript)||media.episodeTranscript.some(x=>typeof x.time!=='string'||typeof x.text!=='string'||x.time.length>32||x.text.length>2000)))throw Error('Transcript must be an array of short time/text records');
const audioSource=media?.episodeAudioPath?resolve(dirname(resolve(input)),'public',media.episodeAudioPath.slice(1)):null;
if(audioSource&&!existsSync(audioSource))throw Error('Missing owned audio '+media.episodeAudioPath+'; put it beside your Site Brief in public/audio/');
const root=resolve(dest);
if(existsSync(root)&&readdirSync(root).length)throw Error('Output directory must be empty');
const settings={version:1,layoutDefinitionVersion:1,layoutAdapter:layoutDefinition.adapter?.id??null,assemblyStatus:layoutDefinition.assemblyStatus,kind:plan.kind,layoutSlug:plan.layoutSlug,visualTheme:plan.visualTheme,brand:plan.brand,navigation:nav,primaryCta:plan.primaryCta,sectionPatterns:selections,content,about,media,reading,serviceFacts,team,events,serviceTiming,site:'https://example.com',base:'/'};
const put=(path,body)=>{const p=join(root,path);mkdirSync(join(p,'..'),{recursive:true});writeFileSync(p,body,'utf8')};
put('site.config.json',JSON.stringify(settings,null,2)+'\n');
if(imageSource&&!embedded.has(plan.brand.heroImagePath)){const p=join(root,'public',plan.brand.heroImagePath.slice(1));mkdirSync(dirname(p),{recursive:true});copyFileSync(imageSource,p);}
if(logoSource&&!embedded.has(plan.brand.logoPath)){const p=join(root,'public',plan.brand.logoPath.slice(1));mkdirSync(dirname(p),{recursive:true});copyFileSync(logoSource,p);}
for(const [assetPath,bytes] of embedded){const p=join(root,'public',assetPath.slice(1));mkdirSync(dirname(p),{recursive:true});writeFileSync(p,bytes);}
if(audioSource){const p=join(root,'public',media.episodeAudioPath.slice(1));mkdirSync(dirname(p),{recursive:true});copyFileSync(audioSource,p);}

const assets={"package.json":"{\n  \"name\": \"student-astro-site\",\n  \"type\": \"module\",\n  \"private\": true,\n  \"scripts\": {\n    \"dev\": \"astro dev\",\n    \"build\": \"astro build\",\n    \"preview\": \"astro preview\"\n  },\n  \"dependencies\": {\n    \"astro\": \"^5.14.0\"\n  }\n}","astro.config.mjs":"import {defineConfig} from 'astro/config';\nimport config from './site.config.json' with {type:'json'};\nexport default defineConfig({site:process.env.SITE_URL||process.env.CF_PAGES_URL||config.site,base:process.env.ASTRO_BASE_PATH||config.base,output:'static',trailingSlash:'always'});\n","src/content.config.ts":"import {defineCollection,z} from 'astro:content';\nimport {glob} from 'astro/loaders';\nexport const collections={articles:defineCollection({loader:glob({pattern:'**/*.md',base:'./src/content/articles'}),schema:z.object({title:z.string(),description:z.string(),publishedAt:z.coerce.date(),draft:z.boolean().default(false),tags:z.array(z.string()).default([])})})};\n","src/content/articles/.gitkeep":"","src/content/drafts/.gitkeep":"","src/layouts/SiteLayout.astro":"---\nimport config from '../../site.config.json';\nconst {title,description=config.brand.tagline,searchable=true}=Astro.props;\nconst base=import.meta.env.BASE_URL;\n---\n<!doctype html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\"/><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"/><title>{title===config.brand.name ? title : `${title}｜${config.brand.name}`}</title><meta name=\"description\" content={description}/><link rel=\"canonical\" href={new URL(Astro.url.pathname,Astro.site??Astro.url).href}/><link rel=\"stylesheet\" href={base+'site.css'}/></head>\n<body><a href=\"#main\" class=\"skip\">跳到主要內容</a><header><a class=\"brand\" href={base}>{config.brand.name}</a><nav aria-label=\"主要導覽\">{config.navigation.map(x=><a href={base+(x.path??x.id+'/')}>{x.label}</a>)}</nav><a class=\"button\" href={base+(config.navigation.find(x=>x.id===config.primaryCta.pageId)?.path??config.primaryCta.pageId+'/')}>{config.primaryCta.label}</a></header><main id=\"main\" data-pagefind-body={searchable ? true : undefined}><slot/></main><footer>© {new Date().getFullYear()} {config.brand.name}</footer></body></html>","src/pages/index.astro":"---\nimport config from '../../site.config.json';\nimport SiteLayout from '../layouts/SiteLayout.astro';\nconst base=import.meta.env.BASE_URL;\n---\n<SiteLayout title={config.brand.name}><section class:list={['hero','layout-'+config.layoutSlug]}><p class=\"eyebrow\">{config.kind==='knowledge'?'閱讀與內容':'專業服務'}</p><h1>{config.brand.name}</h1><p>{config.brand.tagline}</p><a class=\"button\" href={base+(config.navigation.find(x=>x.id===config.primaryCta.pageId)?.path??config.primaryCta.pageId+'/')}>{config.primaryCta.label} →</a></section><section class=\"interior\"><h2>從這裡開始</h2><div class=\"links\">{config.navigation.map((x,i)=><a href={base+(x.path??x.id+'/')}><span>{String(i+1).padStart(2,'0')}</span><strong>{x.label}</strong><span>→</span></a>)}</div></section></SiteLayout>","src/pages/[...page].astro":"---\nimport config from '../../site.config.json';\nimport SiteLayout from '../layouts/SiteLayout.astro';\nexport function getStaticPaths(){return config.navigation.filter(x=>x.id!=='articles').map(item=>({params:{page:(item.path??item.id+'/').slice(0,-1)},props:{item}}))}\nconst {item}=Astro.props;\n---\n<SiteLayout title={item.label}><section class=\"interior\"><h1>{item.label}</h1><p>這裡尚未填入個人的正式內容，請先完成內容與設計驗收再公開。</p></section></SiteLayout>","src/pages/articles/index.astro":"---\nimport config from '../../../site.config.json';\nimport SiteLayout from '../../layouts/SiteLayout.astro';\nimport {getCollection} from 'astro:content';\nexport function getStaticPaths(){return config.navigation.some(x=>x.id==='articles')?[{params:{}}]:[]}\nconst articles=(await getCollection('articles',({data})=>!data.draft)).sort((a,b)=>b.data.publishedAt.getTime()-a.data.publishedAt.getTime());\nconst base=import.meta.env.BASE_URL;\n---\n<SiteLayout title=\"文章\"><section class=\"interior\"><h1>文章</h1>{articles.length?<div class=\"links\">{articles.map(x=><a href={base+'articles/'+x.id+'/'}>{x.data.title} →</a>)}</div>:<p>目前沒有公開文章。</p>}</section></SiteLayout>","src/pages/articles/[slug].astro":"---\nimport config from '../../../site.config.json';\nimport SiteLayout from '../../layouts/SiteLayout.astro';\nimport {getCollection,render} from 'astro:content';\nexport async function getStaticPaths(){if(!config.navigation.some(x=>x.id==='articles'))return [];const list=(await getCollection('articles',({data})=>!data.draft)).sort((a,b)=>b.data.publishedAt.getTime()-a.data.publishedAt.getTime());return list.map((entry,i)=>({params:{slug:entry.id},props:{entry,previous:list[i+1]??null,next:list[i-1]??null}}))}\nconst {entry,previous,next}=Astro.props;\nconst {Content}=await render(entry);\n---\n<SiteLayout title={entry.data.title} description={entry.data.description}><article class=\"interior prose\"><h1>{entry.data.title}</h1><p>{entry.data.description}</p><Content/></article></SiteLayout>","src/pages/404.astro":"---\nimport SiteLayout from '../layouts/SiteLayout.astro';\nconst base=import.meta.env.BASE_URL;\n---\n<SiteLayout title=\"找不到這個頁面\" searchable={false}><section class=\"interior\"><h1>找不到這個頁面</h1><a href={base}>返回首頁 →</a></section></SiteLayout>","public/site.css":":root{--brand:BRAND_HEX;--ink:#28231f;--bg:#f7f5f0;--line:#dad4c9}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.8 system-ui,\"Noto Sans TC\",sans-serif}a{color:inherit}a:focus-visible{outline:3px solid var(--brand);outline-offset:3px}.skip{position:absolute;left:-9999px}.skip:focus{top:8px;left:8px;background:var(--color-surface);color:var(--color-content);padding:6px}header{display:flex;gap:24px;flex-wrap:wrap;align-items:center;padding:20px 4vw;border-bottom:1px solid var(--line)}header nav{margin-left:auto;display:flex;gap:20px;flex-wrap:wrap}.brand{font-weight:700;font-size:23px}.button{border:2px solid var(--brand);padding:10px 20px;border-radius:8px;font-weight:700;text-decoration:none}.hero{padding:clamp(60px,8vw,120px) 6vw;max-width:1200px;margin:auto}.hero h1{font-size:clamp(40px,7vw,90px);line-height:1.15}.eyebrow{font-size:13px;letter-spacing:.15em}.interior{max-width:1060px;padding:40px 24px 100px;margin:auto}.links{display:grid;gap:12px}.links a{display:flex;justify-content:space-between;text-decoration:none;border-bottom:1px solid var(--line);padding:16px 0}.prose{max-width:780px}footer{border-top:1px solid var(--line);padding:36px 4vw}.layout-radio-letter{background:#29251f;color:white}.layout-reading-atlas,.layout-field-notes,.layout-clinician{border-left:5px solid var(--brand)}.layout-coach,.layout-essayist{font-size:1.3em}.layout-companion,.layout-somatic{text-align:center}.layout-curator,.layout-collective{background:#eae4dc}.layout-learning-lab,.layout-trust-path{border-top:5px solid var(--brand)}@media(max-width:650px){header nav{margin-left:0;width:100%}}","README.md":"# 學員獨立 Astro Starter（第一階段）\n\n此匯出功能只提供**可建置的網站骨架**。版型仍須由 AI 根據原始 Layout Library 做真實構圖移植，不可聲稱已完成 12 款版型的視覺還原。\n\n- `npm install` → `npm run dev` → `npm run build`\n- 發布前修改 `site.config.json` 的 `site`、`base`，填寫真實內容。\n- 若使用 GitHub Pages 專案站，需要正確的 BASE_URL；Cloudflare 根網域通常使用 `/`。\n- 使用 astro-site-assembly、astro-starter-deploy、astro-site-maintenance Skills。\n- 未設定的服務、預約、文章不要假裝已經完成。\n"};
assets['.github/workflows/deploy.yml']=[
'name: Publish approved student Astro site',
'on:',
'  workflow_dispatch:',
'    inputs:',
'      approved_sha:',
'        description: Exact reviewed main commit SHA (40 hex)',
'        required: true',
'        type: string',
'      approved_url:',
'        description: Exact reviewed production URL including base path',
'        required: true',
'        type: string',
'permissions:',
'  contents: read',
'  pages: write',
'  id-token: write',
'concurrency:',
'  group: github-pages',
'  cancel-in-progress: false',
'jobs:',
'  deploy:',
'    if: github.ref == \'refs/heads/main\'',
'    runs-on: ubuntu-latest',
'    env:',
'      SITE_INDEXABLE: \u0024{{ vars.SITE_INDEXABLE || \'false\' }}',
'    environment:',
'      name: github-pages',
'      url: \u0024{{ steps.deploy.outputs.page_url }}',
'    steps:',
'      - uses: actions/checkout@v4',
'      - uses: actions/setup-node@v4',
'        with:',
'          node-version: "22"',
'      - run: npm install',
'      - id: pages',
'        uses: actions/configure-pages@v5',
'      - run: npm run build',
'        env:',
'          SITE_URL: \u0024{{ steps.pages.outputs.origin }}',
'          ASTRO_BASE_PATH: \u0024{{ steps.pages.outputs.base_path }}',
'      - name: Release technical gate (not a substitute for human approval)',
'        run: npm run verify:release',
'        env:',
'          SITE_URL: \u0024{{ steps.pages.outputs.origin }}',
'          ASTRO_BASE_PATH: \u0024{{ steps.pages.outputs.base_path }}',
'          RELEASE_SHA: \u0024{{ github.sha }}',
'          RELEASE_APPROVED_SHA: \u0024{{ inputs.approved_sha }}',
'          RELEASE_APPROVED_URL: \u0024{{ inputs.approved_url }}',
'      - uses: actions/upload-pages-artifact@v3',
'        with:',
'          path: dist',
'      - id: deploy',
'        uses: actions/deploy-pages@v4'
].join('\n')+'\n';
// PR checks are intentionally read-only. A public Preview URL needs an actual
// Cloudflare Pages branch deployment or a separately configured safe Pages workflow.
assets['.github/workflows/pr-check.yml']=[
'name: Student PR build verification',
'on:',
'  pull_request:',
'  workflow_dispatch:',
'permissions:',
'  contents: read',
'jobs:',
'  verify:',
'    runs-on: ubuntu-latest',
'    steps:',
'      - uses: actions/checkout@v4',
'      - uses: actions/setup-node@v4',
'        with:',
'          node-version: "22"',
'      - run: npm install --no-audit --no-fund',
'      - name: Prove learner validators reject known-bad output',
'        run: npm run test:regressions',
'      - run: npm run build',
'      - name: Verify site output and draft isolation',
'        run: npm run verify',
'      - uses: actions/upload-artifact@v4',
'        with:',
'          name: student-pr-build',
'          path: dist'
].join('\n')+'\n';
assets['src/pages/index.astro']=assets['src/pages/index.astro'].replace("import SiteLayout from '../layouts/SiteLayout.astro';","import SiteLayout from '../layouts/SiteLayout.astro';\nimport SelectedPatterns from '../components/SelectedPatterns.astro';").replace('</SiteLayout>','<SelectedPatterns page="/" /></SiteLayout>');
assets['src/pages/[...page].astro']=assets['src/pages/[...page].astro'].replace("import SiteLayout from '../layouts/SiteLayout.astro';","import SiteLayout from '../layouts/SiteLayout.astro';\nimport SelectedPatterns from '../components/SelectedPatterns.astro';").replace('</SiteLayout>','<SelectedPatterns page={item.id} /></SiteLayout>');
assets['src/pages/articles/index.astro']=assets['src/pages/articles/index.astro'].replace("import SiteLayout from '../../layouts/SiteLayout.astro';","import SiteLayout from '../../layouts/SiteLayout.astro';\nimport SelectedPatterns from '../../components/SelectedPatterns.astro';").replace('</SiteLayout>','<SelectedPatterns page="articles" /></SiteLayout>');
assets['src/layouts/SiteLayout.astro']=assets['src/layouts/SiteLayout.astro'].replace('{config.brand.name}</a><nav aria-label=',`{config.brand.logoPath?<img src={base+config.brand.logoPath.replace(/^\\//,'')} alt={config.brand.name+' Logo'} width="125" height="48" style="max-width:125px;max-height:48px;object-fit:contain"/>:config.brand.name}</a><nav aria-label=`);
assets['src/layouts/SiteLayout.astro']=assets['src/layouts/SiteLayout.astro'].replace("import config from '../../site.config.json';","import config from '../../site.config.json';\nimport SelectedPatterns from '../components/SelectedPatterns.astro';").replace('<footer>© {new Date().getFullYear()} {config.brand.name}</footer>',"{config.sectionPatterns?.some(x=>x.patternId.startsWith('footer-'))?<SelectedPatterns page=\"site-wide\" />:<footer>© {new Date().getFullYear()} {config.brand.name}</footer>}");
// One reviewed source for desktop/mobile navigation; preserve parentId and native CTA.
assets['src/components/StudentNavigation.astro']=readFileSync(new URL('../src/components/student/StudentNavigation.astro',import.meta.url),'utf8');
assets['src/components/SelectedPatterns.astro']="---\nimport settings from '../../site.config.json';\ninterface Props {page:string}\nconst {page}=Astro.props;\nconst chosen=(settings.sectionPatterns||[]).filter(x=>x.targetPage===page);\nconst isFooter=chosen.some(x=>x.patternId.startsWith('footer-'));\nconst links=settings.navigation;\n---\n{chosen.map(choice=>\n  choice.patternId==='featured-work'?<section class=\"student-pattern\" aria-label=\"精選作品\">\n    <p class=\"pattern-label\">SELECTED WORK / 待完成</p><h2>代表作品與文章</h2><p>已選用作品展示組合樣板。請提供真實作品名稱、介紹與連結後，再由 AI 完成此區段。</p>\n    <p class=\"pattern-note\">規劃位置：{choice.insertAfter}</p>\n  </section>:choice.patternId==='trust-service-path'?<section class=\"student-pattern\" aria-label=\"服務適合度\">\n    <p class=\"pattern-label\">TRUST AND SERVICE / 待完成</p><h2>服務與合作方式</h2><p>已選用服務信任組合樣板。請提供實際服務、適合與不適合情況、必要政策，再由 AI 完成此區段。</p>\n    <p class=\"pattern-note\">規劃位置：{choice.insertAfter}</p>\n  </section>:choice.patternId.startsWith('footer-')?<footer class:list={['student-footer','student-footer--'+choice.patternId]}>\n    <div class=\"student-footer__main\"><div><p class=\"pattern-label\">個人網站</p><strong>{settings.brand.name}</strong><p>{settings.brand.tagline}</p></div>\n    <nav aria-label=\"頁腳導覽\"><h2>網站導覽</h2><div class=\"student-footer__links\">{links.map(x=><a href={import.meta.env.BASE_URL+(x.path??x.id+'/')}>{x.label}</a>)}</div></nav></div>\n    <div class=\"student-footer__bottom\"><small>© {new Date().getFullYear()} {settings.brand.name}</small><span></span></div>\n  </footer>:null\n)}\n<style>\n.student-pattern{margin:clamp(32px,5vw,70px) auto;max-width:1060px;padding:clamp(24px,4vw,48px);background:var(--color-surface);border-top:3px solid var(--color-primary)}\n.student-pattern h2{font-size:clamp(26px,3vw,40px);margin:.3em 0}\n.student-pattern>p:not(.pattern-label){max-width:62ch}\n.pattern-note,.pattern-label{font-size:13px;letter-spacing:.04em}\n.student-footer{display:grid;gap:35px;padding:clamp(30px,6vw,72px) clamp(22px,5vw,80px);border-top:2px solid var(--color-primary)}\n.student-footer__main{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:32px}\n.student-footer__main strong{font-size:clamp(25px,4vw,44px)}\n.student-footer__main h2{font-size:17px}\n.student-footer__links{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 18px}\n.student-footer__links a{display:flex;align-items:center;min-height:44px}\n.student-footer__bottom small{font-size:1rem}\n.student-footer__bottom{border-top:1px solid currentColor;padding-top:20px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;font-size:13px}\n.student-footer--footer-editorial{background:var(--color-surface-alt)}\n.student-footer--footer-professional{background:var(--color-inverse-surface);color:var(--color-on-inverse)}\n.student-footer--footer-minimal{background:var(--color-surface)}\n@media(max-width:720px){.student-footer__main{grid-template-columns:1fr}}\n</style>\n";
assets['src/layouts/SiteLayout.astro']=assets['src/layouts/SiteLayout.astro']
 .replace("import config from '../../site.config.json';","import config from '../../site.config.json';\nimport StudentNavigation from '../components/StudentNavigation.astro';")
 .replace(/<nav aria-label="主要導覽">[^]*?<\/nav>/,'<StudentNavigation />');
// New learner sites and branch previews remain unindexed until explicitly approved.
assets['src/layouts/SiteLayout.astro']=assets['src/layouts/SiteLayout.astro']
 .replace("const base=import.meta.env.BASE_URL;","const base=import.meta.env.BASE_URL;\nconst isBranchPreview=process.env.CF_PAGES==='1'&&(!process.env.CF_PAGES_BRANCH||process.env.CF_PAGES_BRANCH!==(process.env.CF_PAGES_PRODUCTION_BRANCH||'main'));\nconst indexable=process.env.SITE_INDEXABLE==='true'&&!isBranchPreview;")
 .replace('<meta name="description" content={description}/>','<meta name="description" content={description}/><meta name="robots" content={indexable?"index, follow":"noindex, nofollow, noarchive"}/>');
assets['README.md']+='\n搜尋引擎收錄預設關閉。僅在完成內容與預覽驗收、獲得網站擁有者明確同意、並於正式部署環境設定 SITE_INDEXABLE=true 後開放索引；不要在 Preview 分支共用這項正式發布設定。\n';
assets['README.md']+='\n## 部署設定\n\n- GitHub Pages：到 Settings → Pages 把 Source 設為 GitHub Actions。`.github/workflows/deploy.yml` 會用 `actions/configure-pages` 自動帶入網站網址與路徑前綴（專案網站會是 `/倉庫名`），不需要手動改 `site.config.json`。\n- Cloudflare Pages：Framework preset 選 Astro，組建命令 `npm run build`，輸出目錄 `dist`。預覽網址會自動帶入。正式網址或自訂網域要在環境變數設定 `SITE_URL`（含 `https://`）；要開放搜尋引擎收錄，另外設定 `SITE_INDEXABLE=true`。\n- 兩條路線都不需要把網址寫進原始碼；本機開發與沒設定網址時，網站會以示範網址輸出並禁止收錄。\n';
// Generated SEO endpoints belong to the learner website, not the research demo.
assets['src/pages/rss.xml.js'] = `import {getCollection} from 'astro:content';
import config from '../../site.config.json';
const esc=(value)=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[ch]));
export async function GET({site}) {
 const origin=site||new URL(config.site||'https://example.com');
 const base=import.meta.env.BASE_URL;
 const items=config.navigation.some(x=>x.id==='articles')?(await getCollection('articles',({data})=>!data.draft)).sort((a,b)=>b.data.publishedAt-a.data.publishedAt):[];
 const url=(path)=>new URL(base+path,origin).href;
 const body='<?xml version="1.0" encoding="UTF-8"?>'+'<rss version="2.0"><channel><title>'+esc(config.brand.name)+'</title><link>'+esc(url(''))+'</link><description>'+esc(config.brand.tagline)+'</description>'+items.map(x=>'<item><title>'+esc(x.data.title)+'</title><link>'+esc(url('articles/'+x.id+'/'))+'</link><guid>'+esc(url('articles/'+x.id+'/'))+'</guid><pubDate>'+x.data.publishedAt.toUTCString()+'</pubDate><description>'+esc(x.data.description)+'</description></item>').join('')+'</channel></rss>';
 return new Response(body,{headers:{'Content-Type':'application/rss+xml; charset=utf-8'}});
}
`;
assets['src/pages/sitemap.xml.js'] = `import {getCollection} from 'astro:content';
import config from '../../site.config.json';
const esc=(value)=>String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;');
export async function GET({site}) {
 const origin=site||new URL(config.site||'https://example.com');
 const base=import.meta.env.BASE_URL;
 const paths=['',...config.navigation.map(x=>x.path??x.id+'/')];
 if(config.navigation.some(x=>x.id==='articles')) {
  const entries=await getCollection('articles',({data})=>!data.draft);
  for(const x of entries)paths.push('articles/'+x.id+'/');
 }
 const urls=[...new Set(paths)].map(path=>'<url><loc>'+esc(new URL(base+path,origin).href)+'</loc></url>').join('');
 return new Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+urls+'</urlset>',{headers:{'Content-Type':'application/xml; charset=utf-8'}});
}
`;
assets['src/pages/robots.txt.js'] = `export async function GET({site}) {
 const origin=site||new URL('https://example.com');
 const base=import.meta.env.BASE_URL;
 const demo=origin.hostname==='example.com'||origin.hostname.endsWith('.invalid');
 const body='User-agent: *\\n'+(demo?'Disallow: /':'Allow: /')+'\\nSitemap: '+new URL(base+'sitemap.xml',origin).href+'\\n';
 return new Response(body,{headers:{'Content-Type':'text/plain; charset=utf-8'}});
}
`;
assets['src/pages/robots.txt.js']=assets['src/pages/robots.txt.js'].replace("const demo=origin.hostname==='example.com'||origin.hostname.endsWith('.invalid');","const isBranchPreview=process.env.CF_PAGES==='1'&&(!process.env.CF_PAGES_BRANCH||process.env.CF_PAGES_BRANCH!==(process.env.CF_PAGES_PRODUCTION_BRANCH||'main'));\n const demo=isBranchPreview||process.env.SITE_INDEXABLE!=='true'||origin.hostname==='example.com'||origin.hostname.endsWith('.invalid');");
// Supply the same search data contract as the optional SiteSearchDialog Block.
assets['scripts/build-exact-search.mjs']=readFileSync(new URL('./build-student-search-index.mjs',import.meta.url),'utf8');
assets['scripts/audit-generated-links.mjs']=readFileSync(new URL('./audit-generated-links.mjs',import.meta.url),'utf8');
assets['scripts/verify-site-output.mjs']=readFileSync(new URL('./verify-site-output.mjs',import.meta.url),'utf8');
// The built page's public sharing URL must track its canonical rather than an example origin.
assets['src/layouts/SiteLayout.astro']=assets['src/layouts/SiteLayout.astro'].replace(
 '<link rel="canonical" href={new URL(Astro.url.pathname,Astro.site??Astro.url).href}/>',
 '<link rel="canonical" href={new URL(Astro.url.pathname,Astro.site??Astro.url).href}/><meta property="og:url" content={new URL(Astro.url.pathname,Astro.site??Astro.url).href}/>'
);
assets['scripts/verify-release-readiness.mjs']=readFileSync(new URL('./verify-release-readiness.mjs',import.meta.url),'utf8');
assets['scripts/gates.mjs']=readFileSync(new URL('./gates.mjs',import.meta.url),'utf8');
assets['scripts/site-state.mjs']=readFileSync(new URL('./site-state.mjs',import.meta.url),'utf8');
assets['scripts/preflight.mjs']=readFileSync(new URL('./preflight.mjs',import.meta.url),'utf8');
assets['scripts/gates.config.json']=readFileSync(new URL('./gates.config.json',import.meta.url),'utf8');
assets['scripts/design-scan.mjs']=readFileSync(new URL('./design-scan.mjs',import.meta.url),'utf8');
assets['scripts/theme-css.mjs']=readFileSync(new URL('./theme-css.mjs',import.meta.url),'utf8');
assets['scripts/test-release-readiness.mjs']=readFileSync(new URL('./test-release-readiness.mjs',import.meta.url),'utf8');
assets['scripts/test-generated-link-audit.mjs']=readFileSync(new URL('./test-generated-link-audit.mjs',import.meta.url),'utf8');
assets['scripts/test-site-output-regressions.mjs']=readFileSync(new URL('./test-draft-leakage-regressions.mjs',import.meta.url),'utf8').replaceAll('verify-site-output.mjs','verify-site-output.mjs');
const pkg=JSON.parse(assets['package.json']);
assets['scripts/clean-build.mjs']=`import {rmSync} from 'node:fs';
// Empty Astro glob can retain the previous data store. Clear generated output/cache only.
for(const directory of ['dist','.astro','node_modules/.astro'])rmSync(new URL('../'+directory+'/',import.meta.url),{recursive:true,force:true});
`;
pkg.scripts.build='node scripts/clean-build.mjs && astro build && pagefind --site dist --root-selector "[data-pagefind-body]" && node scripts/build-exact-search.mjs && node scripts/audit-generated-links.mjs dist';
pkg.scripts['verify:output']='node scripts/verify-site-output.mjs --student-site .';
pkg.scripts.verify='node scripts/gates.mjs --mode preview';
pkg.scripts['gate:preview']='node scripts/gates.mjs --mode preview';
pkg.scripts['gate:release']='node scripts/gates.mjs --mode release';
pkg.scripts.preflight='node scripts/preflight.mjs';
pkg.scripts['verify:release']='node scripts/verify-release-readiness.mjs .';
pkg.scripts['test:release']='node scripts/test-release-readiness.mjs';
pkg.scripts['test:regressions']='node scripts/test-generated-link-audit.mjs && node scripts/test-site-output-regressions.mjs && node scripts/test-release-readiness.mjs';
pkg.devDependencies={...pkg.devDependencies,pagefind:'^1.5.0'};
assets['package.json']=JSON.stringify(pkg,null,2)+'\n';
// Export the actual selected homepage adapter as independent source, not a generic homepage with a layout class.
if(hasAssemblyAdapter){
assets['src/pages/index.astro'] = `---\nimport config from '../../site.config.json';\nimport SiteLayout from '../layouts/SiteLayout.astro';\nimport Home from '../components/layouts/selected/Home.astro';\nimport SelectedPatterns from '../components/SelectedPatterns.astro';\n---\n<SiteLayout title={config.brand.name}><Home/><SelectedPatterns page="/" /></SiteLayout>`;
assets['src/components/layouts/selected/Home.astro']=readFileSync(new URL('../src/data/layout-assembly/'+layoutDefinition.adapter.id+'/Home.astro',import.meta.url),'utf8');
assets['README.md']+='\n## Selected visual composition\n\nLayout: '+layoutDefinition.title+' ('+layoutDefinition.slug+'). The independent homepage renderer is src/components/layouts/selected/Home.astro. Update site.config.json for brand content and navigation; edit the renderer to replace example notes, illustrations and image slots with real owned material. The original prototype is '+layoutDefinition.sourcePrototype+'. The generated site needs human visual review before launch.\n';
}else{
assets['README.md']+='\n## Prototype-only selection\n\nIMPORTANT: '+layoutDefinition.title+' ('+layoutDefinition.slug+') currently has NO faithful layout adapter. This export is a **generic scaffold** only, NOT a ready-made site that reproduces the prototype. Open '+layoutDefinition.sourcePrototype+' and let AI build the actual composition before deployment.\n';
}
// Typography and image treatment adjust presentation; the chosen layout DOM and section order are untouched.
assets['README.md']+='\n## Brand typography and images\n\nThe brand typography preset and image style are configured in site.config.json. If heroImagePath is set, place that exact licensed image under public/images/ and provide meaningful heroImageAlt. The exporter does not fetch remote images or invent licenses.\n';

if(hasAssemblyAdapter){
 assets['src/components/layouts/selected/DesignInterior.astro']=readFileSync(new URL('../src/data/layout-assembly/DesignInterior.astro',import.meta.url),'utf8');
 assets['src/components/blocks/FAQ.astro']=readFileSync(new URL('../src/components/blocks/FAQ.astro',import.meta.url),'utf8');
 assets['src/components/layouts/selected/ServiceSections.astro']=readFileSync(new URL('../src/data/layout-assembly/ServiceSections.astro',import.meta.url),'utf8');
 assets['src/components/layouts/selected/AboutSections.astro']=readFileSync(new URL('../src/data/layout-assembly/AboutSections.astro',import.meta.url),'utf8');
 assets['src/components/layouts/selected/ArticleArchive.astro']=readFileSync(new URL('../src/data/layout-assembly/ArticleArchive.astro',import.meta.url),'utf8');
 assets['src/components/layouts/selected/ArticleDetail.astro']=readFileSync(new URL('../src/data/layout-assembly/ArticleDetail.astro',import.meta.url),'utf8');
 assets['public/design-family.css']=readFileSync(new URL('../src/data/layout-assembly/DesignChrome.css',import.meta.url),'utf8');
 assets['src/layouts/SiteLayout.astro']=assets['src/layouts/SiteLayout.astro'].replace("<link rel=\"stylesheet\" href={base+'site.css'}/>","<link rel=\"stylesheet\" href={base+'site.css'}/><link rel=\"stylesheet\" href={base+'design-family.css'}/>").replace('<body><a href=','<body data-site-family={config.layoutSlug} data-brand-palette={config.brand.palette?"custom":"family"}><a href=');
 for(const page of ['src/pages/[...page].astro','src/pages/articles/index.astro','src/pages/articles/[slug].astro']){
  assets[page]=assets[page].replace("import SiteLayout from '../layouts/SiteLayout.astro';","import SiteLayout from '../layouts/SiteLayout.astro';\nimport DesignInterior from '../components/layouts/selected/DesignInterior.astro';")
   .replace("import SiteLayout from '../../layouts/SiteLayout.astro';","import SiteLayout from '../../layouts/SiteLayout.astro';\nimport DesignInterior from '../../components/layouts/selected/DesignInterior.astro';");
 }
 assets['src/pages/[...page].astro']=assets['src/pages/[...page].astro'].replace("import DesignInterior from '../components/layouts/selected/DesignInterior.astro';","import DesignInterior from '../components/layouts/selected/DesignInterior.astro';\nimport ServiceSections from '../components/layouts/selected/ServiceSections.astro';\nimport AboutSections from '../components/layouts/selected/AboutSections.astro';");
 assets['src/pages/[...page].astro']=assets['src/pages/[...page].astro'].replace(
  '<section class="interior"><h1>{item.label}</h1><p>這裡尚未填入個人的正式內容，請先完成內容與設計驗收再公開。</p></section>',
  '<DesignInterior title={item.label} kicker={item.id.toUpperCase()} mode="page">{item.id==="about"?<AboutSections/>:["services","faq","booking","first-visit"].includes(item.id)&&config.kind==="helper"?<ServiceSections mode={item.id}/>:<div class="family-empty" data-content-state="unconfigured"><h2>{item.id==="faq"?"常見問題":"頁面內容"}</h2><p>這個頁面尚未提供正式內容。請站長與 AI 確認資訊、圖片和連結後再公開。</p>{item.id==="faq"&&<p>待確認：訪客真正關心的問題與有事實依據的回答。</p>}</div>}</DesignInterior>');
 assets['src/pages/articles/index.astro']=assets['src/pages/articles/index.astro'].replace(
  '<section class="interior"><h1>文章</h1>{articles.length?<div class="links">{articles.map(x=><a href={base+\'articles/\'+x.id+\'/\'}>{x.data.title} →</a>)}</div>:<p>目前沒有公開文章。</p>}</section>',
  '<DesignInterior title="文章與觀點" kicker="ARCHIVE" mode="listing">{articles.length?<div class="family-articles">{articles.map((x,i)=><a class="family-article-link" href={base+\'articles/\'+x.id+\'/\'}><span class="family-article-index">{String(i+1).padStart(2,\'0\')}</span><span class="family-article-copy"><strong>{x.data.title}</strong><span>{x.data.description}</span></span><time datetime={x.data.publishedAt.toISOString()}>{x.data.publishedAt.toLocaleDateString(\'zh-TW\')}</time><span aria-hidden="true">↗</span></a>)}</div>:<p>目前沒有公開文章。新增經本人確認的文章後，這裡會自動顯示。</p>}</DesignInterior>');
 assets['src/pages/articles/index.astro']=assets['src/pages/articles/index.astro']
  .replace("import DesignInterior from '../../components/layouts/selected/DesignInterior.astro';","import DesignInterior from '../../components/layouts/selected/DesignInterior.astro';\nimport ArticleArchive from '../../components/layouts/selected/ArticleArchive.astro';")
  .replace(/\{articles\.length\?<div class="family-articles">[\s\S]*?<\/DesignInterior>/,'<ArticleArchive articles={articles}/></DesignInterior>');
 assets['src/pages/articles/[slug].astro']=assets['src/pages/articles/[slug].astro'].replace("import DesignInterior from '../../components/layouts/selected/DesignInterior.astro';","import DesignInterior from '../../components/layouts/selected/DesignInterior.astro';\nimport ArticleDetail from '../../components/layouts/selected/ArticleDetail.astro';");
 assets['src/pages/articles/[slug].astro']=assets['src/pages/articles/[slug].astro'].replace(
  '<article class="interior prose"><h1>{entry.data.title}</h1><p>{entry.data.description}</p><Content/></article>',
  '<ArticleDetail entry={entry} previous={previous} next={next}><Content/></ArticleDetail>');
}
assets['public/tokens.css']=readFileSync(new URL('../src/styles/tokens.css',import.meta.url),'utf8');
assets['public/theme.css']=themeCss(settings.brand);
assets['src/layouts/SiteLayout.astro']=assets['src/layouts/SiteLayout.astro'].replace("<link rel=\"stylesheet\" href={base+'site.css'}/>","<link rel=\"stylesheet\" href={base+'tokens.css'}/><link rel=\"stylesheet\" href={base+'theme.css'}/><link rel=\"stylesheet\" href={base+'site.css'}/>");
pkg.scripts['sync:theme']='node scripts/theme-css.mjs';
pkg.scripts.predev='node scripts/theme-css.mjs';
pkg.scripts.prebuild='node scripts/theme-css.mjs';
assets['package.json']=JSON.stringify(pkg,null,2)+'\n';
for(const [path,body] of Object.entries(assets)){
  if(path.startsWith('src/pages/articles/')&&!nav.some(x=>x.id==='articles'))continue;
  // 主題輸入與語意 Token 已移到 public/theme.css（由 site.config.json 產生）與 public/tokens.css；site.css 不再自帶 :root 色票。
  let actual=path==='public/site.css'?body.replace(/^:root\{--brand:BRAND_HEX;[^}]*\}/,''):body;
  if(path==='public/site.css'){
    // Only the shared site chrome receives these rules. Never restyle editorial
    // headers, footers or navigation that belong to an independent layout.
    actual=actual.replace(/(^|})header\{/g,'$1body>header{')
      .replace(/header nav/g,'body>header nav')
      .replace(/(^|})footer\{/g,'$1body>footer{');
    actual+='\nbody{font-family:var(--brand-body-font,system-ui,sans-serif)}.interior h1,.interior h2,.interior h3{font-family:var(--brand-heading-font,Georgia,serif)}.interior{max-width:1060px;margin-inline:auto}\n';
  }
  if(path==='src/pages/articles/index.astro')actual=actual.replace(/export function getStaticPaths\(\)\{return config\.navigation\.some\(x=>x\.id==='articles'\)\?\[\{params:\{\}\}\]:\[\]\}\n/,'');
  put(path,actual);
}
if(!process.argv.includes('--defer-student-context')){
 finalizeStudentSite(root,plan);
 cpSync(new URL('../.ai/',import.meta.url),join(root,'.ai'),{recursive:true,force:false,errorOnExist:true});
}
// G-11：記下出廠時各檔案的寫死色數量（之後只有新增的才算違規）。
writeDesignBaseline(root);
console.log('Generated independent Astro scaffold:',root,'pages:',nav.map(x=>x.id));
